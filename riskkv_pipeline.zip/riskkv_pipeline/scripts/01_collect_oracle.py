#!/usr/bin/env python3
import argparse, json, time
from pathlib import Path
import pandas as pd
from tqdm import tqdm
from riskkv.config import load_config, validate_config
from riskkv.data import load_requests
from riskkv.policies import PolicySpec
from riskkv.backend import KVPressBackend
from riskkv.features import extract_prefill_features
from riskkv.metrics import score
from riskkv.utils import seed_everything, ensure_dir

p=argparse.ArgumentParser(); p.add_argument('--config',default='configs/default.yaml'); p.add_argument('--output',default='results/oracle.csv'); p.add_argument('--limit',type=int,default=None); a=p.parse_args()
cfg=validate_config(load_config(a.config)); seed_everything(int(cfg.get('seed',42)))
reqs=load_requests(cfg['data']['input_jsonl']); reqs=reqs[:a.limit] if a.limit else reqs
m=cfg['model']; backend=KVPressBackend(m['name'],device=m.get('device','cuda:0'),dtype=m.get('dtype','auto'),device_map=m.get('device_map'),trust_remote_code=m.get('trust_remote_code',False))
policies=[PolicySpec.from_dict(x) for x in cfg['policies']]
rows=[]
for r in tqdm(reqs,desc='requests'):
    feats=extract_prefill_features(backend.model,backend.tokenizer,r['context'],r['question'],max_tokens=int(m.get('feature_max_tokens',32768)))
    per=[]
    for pol in policies:
        gr=backend.generate(r['context'],r['question'],pol,max_new_tokens=m.get('max_new_tokens',64),do_sample=m.get('do_sample',False),temperature=m.get('temperature',0.0))
        q=score(gr.answer,r['reference'],r.get('metric','f1'))
        per.append((pol,gr,q))
    full=[x for x in per if x[0].name=='full'][0][2]
    for pol,gr,q in per:
        row={'request_id':r['request_id'],'task':r.get('task','unknown'),'metric':r.get('metric','f1'),'policy':pol.name,'family':pol.family,'memory_ratio':pol.memory_ratio,'reference':r['reference'],'answer':gr.answer,'quality':q,'full_quality':full,'degradation':max(0.0,full-q),'actual_seconds':gr.total_seconds,'actual_peak_gpu_bytes':gr.peak_gpu_bytes,'actual_allocated_gpu_bytes':gr.allocated_gpu_bytes,**feats}
        rows.append(row)
out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); pd.DataFrame(rows).to_csv(out,index=False); print(f'Wrote {len(rows)} rows to {out}')
