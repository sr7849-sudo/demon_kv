from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class PolicySpec:
    name: str
    family: str
    compression_ratio: float=0.0
    memory_ratio: float=1.0
    nbits: int|None=None
    backend: str|None=None

    @classmethod
    def from_dict(cls,d):
        return cls(name=d["name"], family=d["family"], compression_ratio=float(d.get("compression_ratio",0.0)),
                   memory_ratio=float(d.get("memory_ratio",1.0)), nbits=d.get("nbits"), backend=d.get("backend"))


def build_runtime_policy(spec: PolicySpec):
    """Return (press, cache). Imports are lazy so analysis scripts work without GPU deps."""
    if spec.family=="full": return None,None
    if spec.family=="snapkv":
        from kvpress import SnapKVPress
        return SnapKVPress(compression_ratio=spec.compression_ratio),None
    if spec.family=="knorm":
        from kvpress import KnormPress
        return KnormPress(compression_ratio=spec.compression_ratio),None
    if spec.family=="streaming":
        from kvpress import StreamingLLMPress
        return StreamingLLMPress(compression_ratio=spec.compression_ratio),None
    if spec.family=="quantized":
        from transformers import QuantizedCache
        if spec.nbits is None: raise ValueError(f"{spec.name}: nbits required")
        return None,QuantizedCache(backend=spec.backend or "quanto", nbits=int(spec.nbits))
    raise ValueError(f"Unknown policy family '{spec.family}'")
