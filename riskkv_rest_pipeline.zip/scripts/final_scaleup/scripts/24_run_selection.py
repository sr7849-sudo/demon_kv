from riskkv.selection.controller import main
if __name__=='__main__': main()
